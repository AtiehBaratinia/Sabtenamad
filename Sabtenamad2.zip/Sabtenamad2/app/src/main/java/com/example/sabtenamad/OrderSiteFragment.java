package com.example.sabtenamad;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class OrderSiteFragment extends Fragment implements View.OnClickListener {

    RecyclerView recyclerView;
    RecyclerView.Adapter adapter;
    RecyclerView.LayoutManager layoutManager;

    Button button;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_order_site, container, false);

        ArrayList<CardInformationDesignSiteItem> items = new ArrayList<>();
        items.add(new CardInformationDesignSiteItem("طراحی سایت", getResources().getString(R.string.body_design_site)
                , R.drawable.img_design_site));
        items.add(new CardInformationDesignSiteItem("طراحی اپلیکیشن", getResources().getString(R.string.body_design_app), R.drawable.image_design_app));
        items.add(new CardInformationDesignSiteItem("خدمات سئو", getResources().getString(R.string.body_seo), R.drawable.seo));
        items.add(new CardInformationDesignSiteItem("طراحی لوگو", getResources().getString(R.string.body_logo), R.drawable.seo));

        recyclerView = view.findViewById(R.id.recycler_view_design_page);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getContext());
        adapter = new AdapterDesignSite(items);

        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);

        button = view.findViewById(R.id.button_order_site);
        button.setOnClickListener(this);
        return view;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.button_order_site:
                makeDialog();
                break;
        }
    }
    public void makeDialog(){
        final AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View view = getLayoutInflater().inflate(R.layout.order_site_dialog, null);
        EditText email = view.findViewById(R.id.email_for_order_site);
        EditText name = view.findViewById(R.id.name_for_order_site);
        EditText call = view.findViewById(R.id.call_for_order_site);
        EditText explanation = view.findViewById(R.id.explanation_for_order_site);
        Button buttonOrderSite = view.findViewById(R.id.send_order_site_request);

        builder.setView(view);

        final AlertDialog dialog = builder.create();
        dialog.show();

        buttonOrderSite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(), "درخواست ثبت شد.", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        });

    }
}
