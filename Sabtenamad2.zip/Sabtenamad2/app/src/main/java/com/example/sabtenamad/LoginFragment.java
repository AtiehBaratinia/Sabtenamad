package com.example.sabtenamad;

import android.app.AlertDialog;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginFragment extends Fragment implements View.OnClickListener {

    Button createAccount;
    Button enter;
    TextView forgetPassword;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login, container, false);

        forgetPassword = view.findViewById(R.id.forget_password);
        forgetPassword.setOnClickListener(this);
        enter = view.findViewById(R.id.button_login);
        createAccount = view.findViewById(R.id.button_create_account);
        createAccount.setOnClickListener(this);
        return view;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.button_create_account:
                if (getActivity() != null) {
                    getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                            new RegisterFragment()).commit();
                }
                break;
            case R.id.forget_password:
                forgetPasswordDialog();
                break;
        }
    }
    public void forgetPasswordDialog(){
        final AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View view = getLayoutInflater().inflate(R.layout.order_site_dialog, null);
        EditText email = view.findViewById(R.id.email_address_forgot_password);
        Button sendPasswordLink = view.findViewById(R.id.send_password_reset_link);

        builder.setView(view);

        final AlertDialog dialog = builder.create();
        dialog.show();

        sendPasswordLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(), "لینک فرستاده شد، ایمیل خود را چک کنید.", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        });

    }
}
