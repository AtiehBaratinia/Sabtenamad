package com.example.sabtenamad;

public class CardInformationDesignSiteItem {
    String title, body;
    int image;
    public CardInformationDesignSiteItem(String title, String body, int image){
        this.title = title;
        this.body = body;
        this.image = image;
    }

    public int getImage() {
        return image;
    }

    public String getBody() {
        return body;
    }

    public String getTitle() {
        return title;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
