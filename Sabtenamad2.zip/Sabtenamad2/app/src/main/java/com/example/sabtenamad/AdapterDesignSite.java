package com.example.sabtenamad;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class AdapterDesignSite extends RecyclerView.Adapter<AdapterDesignSite.AdapterDesignSiteViewHolder>{

    ArrayList<CardInformationDesignSiteItem> items;
    @NonNull
    @Override
    public AdapterDesignSite.AdapterDesignSiteViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.card_information_design_site, viewGroup, false);
        AdapterDesignSite.AdapterDesignSiteViewHolder rvh = new AdapterDesignSiteViewHolder(view);
        return rvh;
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterDesignSite.AdapterDesignSiteViewHolder holder, int position) {
        CardInformationDesignSiteItem currentItem = items.get(position);

        holder.imageView.setImageResource(currentItem.getImage());
        holder.body.setText(currentItem.getBody());
        holder.title.setText(currentItem.getTitle());


    }

    public AdapterDesignSite(ArrayList<CardInformationDesignSiteItem> items) {
        this.items = items;
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public static class AdapterDesignSiteViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView title;
        TextView body;

        public AdapterDesignSiteViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.card_item_image);
            title = itemView.findViewById(R.id.card_item_title);
            body = itemView.findViewById(R.id.card_item_body_text);
        }
    }
}
